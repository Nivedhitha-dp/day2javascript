// loops 
// while 
// do-while 
// for 

// let num=1;

// while(num<=10)
// {
//     console.log(num);
//     num++;
    
// }


// let num=11;

// do 
// {
//     console.log(num);
//     num++;
// }
// while(num<=10);



// for(let num=1;num<=10;num++)
// {
//     console.log(num);
// }


// arrays 

// let data=["Thor","Captain","ironman","hulk","hawkeye"];

// console.log(data[0]);
// console.log(data[1]);
// console.log(data[2]);
// console.log(data[3]);
// console.log(data[4]);

// for(let num=0;num<data.length;num++){
//     console.log(data[num]);
// }

// Object

// let student={
//     name:"Saurabh",
//     age:26,
//     stream:"science"
// }

// student.city="Mumbai";

// console.log(student);

// let property="stream";

// console.log(student.property);

// console.log(student.name);
// console.log(student.age);

// console.log(student[property]);


let students=[
    {
        name:"Saurabh",
        age:26,
        hobbies:["cricket","volleyball","video games"]
    }
    ,
    {
        name:"Thor",
        age:1500
    }
    ,
    {
        name:"Hawkeye",
        age:30
    }
]


// students[3]={name:"Hulk",age:34};

students.push({name:"Hulk",age:34});
// students.unshift({name:"Hulk",age:34});






for(let num=0;num<students.length;num++){
    console.log(students[num]);
}





















































